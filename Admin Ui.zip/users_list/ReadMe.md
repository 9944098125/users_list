Set Up Instructions:
Download dependencies by running 'npm install'
Start up the app using 'npm start'

Functionalities achieved:
1. Should render the data from the url:'https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json'
2.The list of users should be shown in the format of pages.
3.The row of a user should contain a checkbox, delete, and edit button.
4.If the top-most checkbox is selected, then all the checkboxes should be selected.
5. If the delete button in a row is clicked then that row should be deleted.
6. In the bottom there should be a button 'Delete selected' to delete the rows that are selected through the checkboxes.
12.If the edit button is clicked, the user must be able to edit the row.
13.There should be search bar in the top to search a user.

Quick tips:
1. The icon {AiFillDelete} from react-icons can be used for delete icon.
2. The icon {BiEdit} from react-icons can be used for edit icon.


Things to Keep in Mind:
1. All components you implement should go in the src/components directory.
2. Don't change the component folder names as those are the files being imported into the tests.