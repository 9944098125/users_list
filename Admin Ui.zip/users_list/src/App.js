import Admin from './components/Admin'



const App = () => (
  <Admin />
)

export default App